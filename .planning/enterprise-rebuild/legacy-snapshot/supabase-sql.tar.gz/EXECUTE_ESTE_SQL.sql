-- ============================================================================
-- URGENTE: Execute este SQL no Supabase SQL Editor antes de continuar
-- ============================================================================
--
-- Como executar:
-- 1. Acesse: https://supabase.com/dashboard/project/bugpetfkyoraidyxmzxu/sql
-- 2. Copie e cole este SQL completo
-- 3. Clique em "Run" ou pressione Ctrl+Enter
-- 4. Volte para o terminal e continue o upsert
--
-- ============================================================================

-- Verificar se PRIMARY KEY já existe
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint c
    JOIN pg_class t ON c.conrelid = t.oid
    WHERE t.relname = 'reviews' AND c.contype = 'p'
  ) THEN
    -- Adicionar PRIMARY KEY na coluna review_id
    ALTER TABLE reviews ADD PRIMARY KEY (review_id);
    RAISE NOTICE '✅ PRIMARY KEY adicionado com sucesso em reviews(review_id)';
  ELSE
    RAISE NOTICE '✅ PRIMARY KEY já existe em reviews(review_id)';
  END IF;
END $$;

-- Verificar constraints depois da mudança
SELECT
  conname AS constraint_name,
  CASE contype
    WHEN 'p' THEN 'PRIMARY KEY'
    WHEN 'u' THEN 'UNIQUE'
    WHEN 'f' THEN 'FOREIGN KEY'
    WHEN 'c' THEN 'CHECK'
    ELSE contype::text
  END AS constraint_type,
  pg_get_constraintdef(oid) AS definition
FROM pg_constraint
WHERE conrelid = 'reviews'::regclass
ORDER BY contype, conname;
