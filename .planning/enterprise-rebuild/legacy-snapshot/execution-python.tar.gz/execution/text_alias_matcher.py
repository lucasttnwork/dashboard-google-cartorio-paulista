"""
Busca textual determinística de aliases de colaboradores em reviews existentes.
Não usa LLM — varredura direta por regex com word boundaries.

Uso:
  python execution/text_alias_matcher.py
  python execution/text_alias_matcher.py --collaborator-ids 26 27 28 29 30
  python execution/text_alias_matcher.py --all-active

Saída: .tmp/text_matches_<timestamp>.json (mesmo formato do review_alias_imputer,
compatível com upsert_collaborator_aliases.py)
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


PAGE_SIZE = 1000


def validate_env_var(name: str) -> str:
    value = os.getenv(name)
    if not value:
        print(f"[ERROR] Variável de ambiente {name} não encontrada.", file=sys.stderr)
        sys.exit(1)
    return value


def build_session() -> requests.Session:
    session = requests.Session()
    retries = Retry(
        total=3,
        backoff_factor=0.5,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET"],
    )
    adapter = HTTPAdapter(max_retries=retries)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


def fetch_all_reviews(
    session: requests.Session,
    supabase_url: str,
    headers: Dict[str, str],
) -> List[Dict[str, Any]]:
    """Busca todas as reviews com comentário, paginando de PAGE_SIZE em PAGE_SIZE."""
    all_reviews: List[Dict[str, Any]] = []
    offset = 0
    while True:
        params = {
            "select": "review_id,comment,create_time",
            "comment": "not.is.null",
            "order": "create_time.asc",
            "limit": str(PAGE_SIZE),
            "offset": str(offset),
        }
        resp = session.get(
            f"{supabase_url}/rest/v1/reviews",
            headers=headers,
            params=params,
            timeout=30,
        )
        resp.raise_for_status()
        batch = resp.json()
        if not batch:
            break
        all_reviews.extend(batch)
        print(f"  [fetch] {len(all_reviews)} reviews carregadas...", end="\r")
        if len(batch) < PAGE_SIZE:
            break
        offset += PAGE_SIZE
    print(f"  [fetch] {len(all_reviews)} reviews carregadas total.  ")
    return all_reviews


def fetch_collaborators(
    session: requests.Session,
    supabase_url: str,
    headers: Dict[str, str],
    collaborator_ids: Optional[List[int]],
    all_active: bool,
) -> List[Dict[str, Any]]:
    params: Dict[str, str] = {"select": "id,full_name,aliases"}
    if collaborator_ids:
        params["id"] = f"in.({','.join(str(i) for i in collaborator_ids)})"
    elif all_active:
        params["is_active"] = "eq.true"
    resp = session.get(
        f"{supabase_url}/rest/v1/collaborators",
        headers=headers,
        params=params,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


def build_patterns(collaborator: Dict[str, Any]) -> List[tuple[str, re.Pattern[str]]]:
    """
    Retorna lista de (alias_text, compiled_pattern) para um colaborador.
    Usa word boundaries para evitar falsos positivos dentro de palavras maiores.
    """
    aliases = collaborator.get("aliases") or []
    patterns = []
    seen: set[str] = set()
    for alias in aliases:
        if not alias or not alias.strip():
            continue
        normalized = alias.strip()
        key = normalized.lower()
        if key in seen:
            continue
        seen.add(key)
        # \b não funciona bem antes de acentos no Python; usar lookahead/lookbehind
        # para garantir que o match não esteja no meio de outra palavra
        escaped = re.escape(normalized)
        pattern = re.compile(
            r"(?<![A-Za-zÀ-ÖØ-öø-ÿ])" + escaped + r"(?![A-Za-zÀ-ÖØ-öø-ÿ])",
            re.IGNORECASE,
        )
        patterns.append((normalized, pattern))
    return patterns


def extract_context(comment: str, match: re.Match, window: int = 40) -> str:
    start = max(0, match.start() - window)
    end = min(len(comment), match.end() + window)
    snippet = comment[start:end].replace("\n", " ").strip()
    if start > 0:
        snippet = "..." + snippet
    if end < len(comment):
        snippet = snippet + "..."
    return snippet


def scan_reviews(
    reviews: List[Dict[str, Any]],
    collaborators: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    # Pré-compila padrões por colaborador
    collab_patterns = [
        (collab, build_patterns(collab))
        for collab in collaborators
    ]

    records: List[Dict[str, Any]] = []
    matched_reviews = 0

    for review in reviews:
        comment = review.get("comment") or ""
        if not comment.strip():
            continue

        for collab, patterns in collab_patterns:
            for alias_text, pattern in patterns:
                m = pattern.search(comment)
                if m:
                    records.append({
                        "review_id": review["review_id"],
                        "full_name": collab["full_name"],
                        "collaborator_id": collab["id"],
                        "mention_text": alias_text,
                        "context": extract_context(comment, m),
                        "timestamp": datetime.utcnow().isoformat(),
                    })
                    matched_reviews += 1
                    # Apenas o primeiro alias que der match por colaborador por review
                    break

    return records


def persist_results(records: List[Dict[str, Any]]) -> Path:
    output_dir = Path(".tmp")
    output_dir.mkdir(exist_ok=True)
    filename = output_dir / f"text_matches_{datetime.utcnow().strftime('%Y%m%dT%H%M%S')}.json"
    filename.write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
    return filename


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Busca textual de aliases de colaboradores em reviews existentes."
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "--collaborator-ids",
        "-c",
        nargs="+",
        type=int,
        metavar="ID",
        help="IDs dos colaboradores a verificar (padrão: 26 27 28 29 30 — os 5 novos).",
    )
    group.add_argument(
        "--all-active",
        action="store_true",
        help="Varrer aliases de todos os colaboradores ativos.",
    )
    args = parser.parse_args()

    # Padrão: os 5 novos colaboradores
    collaborator_ids: Optional[List[int]] = args.collaborator_ids
    all_active: bool = args.all_active
    if not all_active and not collaborator_ids:
        collaborator_ids = [26, 27, 28, 29, 30]

    supabase_url = validate_env_var("SUPABASE_URL")
    supabase_key = validate_env_var("SUPABASE_SERVICE_ROLE_KEY")
    headers = {
        "apikey": supabase_key,
        "Authorization": f"Bearer {supabase_key}",
    }

    session = build_session()

    print("Carregando colaboradores...")
    collaborators = fetch_collaborators(session, supabase_url, headers, collaborator_ids, all_active)
    if not collaborators:
        print("Nenhum colaborador encontrado com os critérios informados.")
        return
    for c in collaborators:
        alias_count = len(c.get("aliases") or [])
        print(f"  {c['full_name']} — {alias_count} aliases")

    print("\nCarregando reviews...")
    reviews = fetch_all_reviews(session, supabase_url, headers)
    if not reviews:
        print("Nenhuma review com comentário encontrada.")
        return

    print("\nVarrendo comentários...")
    records = scan_reviews(reviews, collaborators)

    if not records:
        print("Nenhuma menção encontrada.")
        return

    output = persist_results(records)

    # Resumo por colaborador
    summary: Dict[str, int] = {}
    for r in records:
        summary[r["full_name"]] = summary.get(r["full_name"], 0) + 1

    print(f"\nTotal de menções encontradas: {len(records)}")
    for name, count in sorted(summary.items(), key=lambda x: -x[1]):
        print(f"  {name}: {count}")

    print(f"\nArquivo gerado: {output}")
    print("Para aplicar no Supabase:")
    print(f"  python execution/upsert_collaborator_aliases.py --file {output}")


if __name__ == "__main__":
    main()
